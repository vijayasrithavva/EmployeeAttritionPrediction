import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
import random
import os


app = Flask(__name__)
if os.path.getsize('model.pkl') > 0:
    model = pickle.load(open('model.pkl', 'rb'))
else:
    print("Hello")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    '''
    For rendering results on HTML GUI
    
    int_features = [int(x) for x in request.form.values()]
    final_features = [np.array(int_features)]
    prediction = model.predict(final_features)

    output = round(prediction[0], 2)'''
    
    eid = request.form['Employee_ID']
    gend = int(request.form['Gender'])
    age = request.form['Age']
    edu_lev = int(request.form['Education_Level'])
    rel_sta = int(request.form['Relationship_Status'])
    hometown = int(request.form['Hometown'])
    unit = int(request.form['Unit'])
    dsp = int(request.form['Decision_skill_possess'])
    tsp = int(request.form['Time_since_promotion'])
    tos = request.form['Time_of_service']
    post_levl = int(request.form['Post_Level'])
    pay_scale = int(request.form['Pay_Scale'])
    trav_rate = int(request.form['Travel_Rate'])
    cab = int(request.form['Compensation_and_Benefits'])
    wlb = int(request.form['Work_Life_balance'])
    growth_r = request.form['growth_rate']
    
    var1 = random.choice([1,2,3,4,5])
    var5 = random.choice([1,2,3,4,5])
    var7 = random.choice([1,2,3,4,5]) 
    
    var2 = random.choice([0.751600,-0.104800,-0.961200,-1.817600,-0.008126,1.608100])
    var3 = random.choice([-0.4537, 0.7075, 1.8688, -1.6150, -2.7762])
    var4 = random.choice([2.000000,1.000000,1.891078,3.000000])
    var6 = random.choice([5,6,7,8,9])
    
    features = [gend,age,edu_lev,rel_sta,hometown,unit,dsp,tos,tsp,
                growth_r,trav_rate,post_levl,pay_scale,cab,wlb,var1,
                var2,var3,var4,var5,var6,var7]
    final_features = [np.array(features)]
    prediction = model.predict(final_features)

    output = round(prediction[0], 2)

    return render_template('index.html', prediction_text='Employee Attrition :{}'.format(output))

@app.route('/predict_api',methods=['POST'])
def predict_api():
    '''
    For direct API calls trought request
    '''
    data = request.get_json(force=True)
    prediction = model.predict([np.array(list(data.values()))])

    output = prediction[0]
    return jsonify(output)

if __name__ == "__main__":
    app.run(debug=True)
# -*- coding: utf-8 -*-

import requests

url = 'http://localhost:5000/predict_api'
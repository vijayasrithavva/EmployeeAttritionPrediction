# -*- coding: utf-8 -*-

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder as le
from imblearn import over_sampling
from imblearn.over_sampling import RandomOverSampler
from collections import Counter
from sklearn.neighbors import KNeighborsClassifier

attrition_data = pd.read_csv('Train.csv')

null_columns = []
for col in attrition_data.columns:
  if attrition_data[col].isnull().any() == True:
    null_columns.append(col)
    
def fillNullValues(data,col):
  data[col].fillna((data[col].mean()),inplace=True)
  
for col in null_columns:
  fillNullValues(attrition_data,col)
  
attrition_data = attrition_data.drop(['Employee_ID'], axis = 1)

  
Attrition = list(attrition_data['Attrition_rate'].round(decimals=0))
attrition_data['Attrition'] = Attrition
attrition_data['Attrition'] = le().fit_transform(attrition_data['Attrition'])

#Label encoding
for col in attrition_data.columns:
  if attrition_data[col].dtype == 'int64'or attrition_data[col].dtype == 'float64':
    continue
  else:
    attrition_data[col] = le().fit_transform(attrition_data[col])

#OverSampling
X = attrition_data.drop(['Attrition', 'Attrition_rate'], axis = 1)
Y = attrition_data['Attrition']
ros = RandomOverSampler(random_state=0)
x_resampled, y_resampled = ros.fit_resample(X, Y)
    
#Splitting Training and Test Set
X_train, X_test, y_train, y_test = train_test_split(x_resampled, y_resampled, test_size=0.25, random_state=42)
from sklearn.preprocessing import StandardScaler 
sc = StandardScaler() 
X_train = sc.fit_transform(X_train) 
X_test = sc.transform(X_test)
#Since we have a very small dataset, we will train our model with all availabe data.
knn = KNeighborsClassifier(n_neighbors=1)
knn.fit(X_train, y_train)
Y_pred_test = knn.predict(X_test)
Y_pred_train = knn.predict(X_train)


# Saving model to disk
pickle.dump(knn, open('model.pkl','wb'))

# Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))